* `Tecnativa <https://www.tecnativa.com>`__:

  * Sergio Teruel

* `GRAP <http://www.grap.coop>`__:

  * Sylvain LE GAL (https://twitter.com/legalsylvain)

* `Open Source Integrators <https://www.opensourceintegrators.com>`__:

  * Bhavesh Odedra

* `Avoin.Systems <https://www.avoin.systems>`__:

  * Nedas Žilinskas

* `Factor Libre <https://factorlibre.com>`__:

  * Luis J. Salvatierra
