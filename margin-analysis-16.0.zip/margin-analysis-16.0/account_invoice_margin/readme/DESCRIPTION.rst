This module allows to show sales margin in invoices.

The new information is available:

* on the invoice form view

.. figure:: ../static/description/account_invoice_form.png
   :scale: 80 %
   :alt: Invoice Tree View

* and on the invoice tree view

.. figure:: ../static/description/account_invoice_tree.png
   :scale: 80 %
   :alt: Invoice Tree View
