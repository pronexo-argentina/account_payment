This module also adds a security group.

#. To activate it go to user and active "Show Invoice Margin" in
   security options.
