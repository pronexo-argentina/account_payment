* `Tecnativa <https://www.tecnativa.com>`__:

  * Sergio Teruel
  * Carlos Dauden
  * Víctor Martínez

* `Open Source Integrators <https://www.opensourceintegrators.com>`__:

  * Bhavesh Odedra

* `Factor Libre <https://www.factorlibre.com>`__:

  * Luis J. Salvatierra
