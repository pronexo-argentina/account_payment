This module propagates purchase price from sale order line to invoice and discards the
invoice lines coming from sale order lines with down-payment when computing the margin.
