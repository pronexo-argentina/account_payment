This module is autoinstalable.
