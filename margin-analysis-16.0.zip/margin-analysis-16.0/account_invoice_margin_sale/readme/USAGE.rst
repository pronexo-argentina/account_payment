This module also needs a security group to show margins.

#. To activate it go to user and active "Show Invoice Margin" in
   security options.
