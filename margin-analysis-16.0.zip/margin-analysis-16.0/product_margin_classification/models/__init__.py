from . import product_margin_classification
from . import product_product
from . import product_template
