* This module will not work for variants that have a not null ``price_extra`` value,
  due to the poor design of Odoo product module.
  This issue can be maybe fixed in new version of Odoo.
