* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Joël Grand-Guillaume <joel.grand-guillaume@camptocamp.com>
* Sylvain Le Gal (https://twitter.com/legalsylvain)
* Cyril Vinh-Tung <cyril@invitu.com>
