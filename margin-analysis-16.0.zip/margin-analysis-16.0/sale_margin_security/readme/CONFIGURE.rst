To grant Sales Margin view privileges to a user:

#. Go to *Settings > Users & Companies > Users*.
#. Select the user.
#. Set *Show Sale Margin* on.
