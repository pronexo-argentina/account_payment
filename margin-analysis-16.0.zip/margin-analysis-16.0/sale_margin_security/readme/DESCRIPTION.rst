This module allows to restrict the access to sale margin fields to a specific
security group of users.
