Only the users in the group *Show Sale Margin* will be able to see sale margin
related fields in the sale lines like `margin` or `purchase_price`.
