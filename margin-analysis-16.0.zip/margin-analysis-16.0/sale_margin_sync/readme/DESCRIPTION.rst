Recompute sale margin when related stock move cost price is changed.
