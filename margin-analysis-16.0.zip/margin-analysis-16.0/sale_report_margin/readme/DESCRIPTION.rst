Adds `purchase_price` field to sale report. This field comes from the *Cost*
field configured in the products themselves and on the defined inventory
valuation method.
