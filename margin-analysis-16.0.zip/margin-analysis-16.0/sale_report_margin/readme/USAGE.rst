Go to *Sales > Reporting > Sales* and you'll find the new *Purchase Price*
measure.
